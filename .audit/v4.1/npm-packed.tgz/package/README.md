Controlled npm pack artifact.
